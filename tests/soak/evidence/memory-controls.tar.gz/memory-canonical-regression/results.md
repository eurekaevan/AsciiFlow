# Compatibility corpus results

Mode: hardware

Support contract: tests/support/production-support-v1.json

| Gate | Category | Result |
|---|---|---|
| all-retained-production | media oracle | PASS |
| av1-pq10 | classification | PASS |
| av1-sdr10 | classification | PASS |
| av1-sdr8 | classification | PASS |
| c1-cpu-reference | runtime | PASS |
| c2b-cpu-reference | runtime | PASS |
| c3-retained-reference | hardware | PASS |
| c4a-retained-reference | hardware | PASS |
| canonical-h2648 | classification | PASS |
| corpus-schema | static | PASS |
| hardware-sdr-input-identity | static | PASS |
| hevc-pq10 | classification | PASS |
| hevc-sdr10 | classification | PASS |
| hevc-sdr8-bframes-audio | classification | PASS |
| media-oracle-controls | media oracle | PASS |
| negative-color-conflict | classification | PASS |
| negative-full-range-pq | classification | PASS |
| negative-h264-high10 | classification | PASS |
| negative-hlg | classification | PASS |
| negative-unknown-color | classification | PASS |
| negative-wide-sdr | classification | PASS |
| smoke-pq-preserve | hardware | PASS |
| smoke-pq-to-sdr | hardware | PASS |
| smoke-pq-to-sdr8 | hardware | PASS |
| smoke-sdr | hardware | PASS |
| support-document-consistency | static | PASS |
| support-planner-consistency | planner | PASS |

## Unexpected failures / passes / rejects

None.

## Skipped hardware

None.
