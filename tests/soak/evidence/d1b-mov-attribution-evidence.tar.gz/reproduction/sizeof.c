#include <stdint.h>
#include <stdio.h>
#include <libavcodec/defs.h>
typedef struct MOVIentry {
    uint64_t     pos;
    int64_t      dts;
    int64_t      pts;
    unsigned int size;
    unsigned int stsd_index;
    unsigned int samples_in_chunk;
    unsigned int chunkNum;              ///< Chunk number if the current entry is a chunk start otherwise 0
    unsigned int entries;
    int          cts;
#define MOV_SYNC_SAMPLE         0x0001
#define MOV_PARTIAL_SYNC_SAMPLE 0x0002
#define MOV_DISPOSABLE_SAMPLE   0x0004
    uint32_t     flags;
    AVProducerReferenceTime prft;
} MOVIentry;
int main(void) { printf("%zu\n", sizeof(MOVIentry)); }
