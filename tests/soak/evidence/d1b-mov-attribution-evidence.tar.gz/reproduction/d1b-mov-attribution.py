"""Exact-package MOV index model against preserved packet traces, not RSS attribution."""
import bisect
from collections import Counter
import ctypes
import hashlib
import json
from pathlib import Path
import subprocess

root = Path('/home/eureka/Documents/AsciiFlow')
old = root / 'target/stage54d1b-long-soak'
out = root / 'target/stage54d1b-mov-attribution'
provenance = json.loads((out / 'source/provenance.json').read_text())
native = out / 'source/ffmpeg-8.1.3/libavformat'
c = (native / 'movenc.c').read_text()
h = (native / 'movenc.h').read_text()
assert '#define MOV_INDEX_CLUSTER_SIZE 1024' in h
assert 'unsigned new_capacity = trk->entry + MOV_INDEX_CLUSTER_SIZE;' in c
assert 'av_realloc_array(trk->cluster, new_capacity, sizeof(*trk->cluster))' in c
assert 'trk->entry++;' in c
assert 'if (mov->flags & FF_MOV_FLAG_HYBRID_FRAGMENTED)' in c
assert provenance['struct_size']['MOVIentry_bytes'] == 72
sha = lambda p: hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
assert sha(native / 'movenc.c') == provenance['movenc_c_sha256_before_and_after_patches']
assert sha(native / 'movenc.h') == provenance['movenc_h_sha256_before_and_after_patches']
library = Path(provenance['installed_libavformat'])
assert sha(library) == provenance['installed_libavformat_sha256']
stack = json.loads((old / 'post/canonical-stack.json').read_text())
assert provenance['installed_libavformat_sha256'] in json.dumps(stack)
runtime = ctypes.CDLL(str(library))
runtime.avformat_version.restype = ctypes.c_uint
runtime.avformat_configuration.restype = ctypes.c_char_p
version = runtime.avformat_version()
identity = {'package_source': provenance, 'runtime_library_sha256': sha(library),
            'runtime_version': f'{version >> 16}.{(version >> 8) & 255}.{version & 255}',
            'runtime_configuration': runtime.avformat_configuration().decode(),
            'matches_recorded_soak_stack_library': True}
primary = json.loads((old / 'production-v1/results.json').read_text())
records = []
for label, kind in zip(('A', 'B', 'C'), ('sdr', 'pq-preserve', 'pq-to-sdr')):
    packets = []
    logs = []
    for suffix in ('-probe', '-audio-output'):
        commands = [x for x in primary['commands'] if x['id'] == kind + suffix]
        if not commands:
            continue
        log = old / 'production-v1' / commands[0]['log']
        logs.append({'path': str(log.relative_to(root)), 'sha256': sha(log)})
        packets.extend(json.loads(log.read_text())['packets'])
    packets.sort(key=lambda p: int(p['pos']))
    ends = [int(p['pos']) + int(p['size']) for p in packets]
    assert ends == sorted(ends)
    video = [p for p in packets if p['codec_type'] == 'video']
    assert len(video) == 100000
    track_ids = sorted({p['stream_index'] for p in packets})
    milestones = []
    for frames in (50000, 99000, 100000):
        # Physical packet trace, not duration/fps estimation. Includes audio
        # physically preceding the Nth video packet, with its AAC priming sample.
        end = int(video[frames - 1]['pos']) + int(video[frames - 1]['size'])
        count = bisect.bisect_right(ends, end)
        entries = Counter(p['stream_index'] for p in packets[:count])
        capacity = {i: ((entries[i] + 1023) // 1024) * 1024 for i in track_ids}
        milestones.append({'video_frames': frames, 'packet_end_offset': end,
                           'total_mux_packets': count,
                           'tracks': [{'stream_index': i, 'entries': entries[i],
                                       'capacity': capacity[i], 'cluster_bytes': capacity[i] * 72}
                                      for i in track_ids],
                           'total_cluster_bytes': sum(capacity.values()) * 72})
    rows = [json.loads(line) for line in (old / 'measurement-v1' / (kind + '-resources.jsonl')).read_text().splitlines()]
    rows = [r for r in rows if r['phase'] == 'progress']
    frame_end = 99000 if label == 'A' else 100000
    before, after = [next(r for r in rows if r['frames_processed'] == frame) for frame in (50000, frame_end)]
    model_before = milestones[0]
    model_after = next(m for m in milestones if m['video_frames'] == frame_end)
    expected_kib = (model_after['total_cluster_bytes'] - model_before['total_cluster_bytes']) / 1024
    observed_kib = after['rss_kib'] - before['rss_kib']
    # The report counter is mux API-accepted, not atomic native cluster state.
    # Check that small asynchronous prefix differences do not change rounding.
    capacity_checks = []
    for row, model in ((before, model_before), (after, model_after)):
        alternative_capacities = []
        for n in (max(0, row['packets_processed'] - 64), row['packets_processed'],
                  min(len(packets), row['packets_processed'] + 64)):
            counts = Counter(p['stream_index'] for p in packets[:n])
            alternative_capacities.append([((counts[i] + 1023) // 1024) * 1024 for i in track_ids])
        expected = [t['capacity'] for t in model['tracks']]
        assert all(caps == expected for caps in alternative_capacities)
        capacity_checks.append({'frames': row['frames_processed'], 'accepted_mux_packets': row['packets_processed'],
                                'physical_video_boundary_packets': model['total_mux_packets'],
                                'same_rounded_capacities_for_plus_minus_64_packet_prefixes': True})
    records.append({'path': label, 'kind': kind, 'packet_trace': logs,
                    'milestones': milestones, 'reported_counter_capacity_check': capacity_checks,
                    'measurement_comparison': {'frames': [50000, frame_end],
                        'rss_kib': [before['rss_kib'], after['rss_kib']],
                        'observed_rss_delta_kib': observed_kib,
                        'expected_cluster_delta_kib': expected_kib,
                        'rss_minus_cluster_delta_kib': observed_kib - expected_kib},
                    'endpoint_note': 'A 100k report overlaps teardown; use last pre-teardown 99k instead.' if label == 'A' else '100k progress, before pre-finalization/cleanup.'})

repeat = json.loads((old / 'long-determinism/frame-correlated-samples.json').read_text())
samples = repeat['samples']
before = min(samples, key=lambda r: abs(r['written_video_frames'] - 50000))
after = min(samples, key=lambda r: abs(r['written_video_frames'] - 100000))
candidate = old / 'long-determinism/output.mp4'
boxes = repeat['top_level_boxes']
assert not any(b['type'] == 'moof' for b in boxes)
assert next(b['offset'] for b in boxes if b['type'] == 'moov') > next(b['offset'] for b in boxes if b['type'] == 'mdat')
probe_command = ['ffprobe', '-v', 'error', '-show_format', '-of', 'json', str(candidate)]
probe = json.loads(subprocess.check_output(probe_command, text=True))
assert probe['format']['format_name'] == 'mov,mp4,m4a,3gp,3g2,mj2'
repeat_points = []
for sample in (before, after):
    n = bisect.bisect_right(ends, sample['written_file_bytes'])
    assert n == sample['written_mux_packets']
    entries = Counter(p['stream_index'] for p in packets[:n])
    tracks = [{'stream_index': i, 'entries': entries[i],
               'capacity': ((entries[i] + 1023) // 1024) * 1024} for i in track_ids]
    repeat_points.append({'actual_written_frames': sample['written_video_frames'],
                          'elapsed_seconds': sample['elapsed_seconds'], 'tracks': tracks,
                          'cluster_kib': sum(t['capacity'] for t in tracks) * 72 / 1024,
                          'rss_kib': sample['VmRSS'], 'pss_kib': sample['Pss'],
                          'anonymous_kib': sample['Anonymous']})
a, b = repeat_points
expected = b['cluster_kib'] - a['cluster_kib']
repeat_deltas = {key: b[key] - a[key] for key in ('rss_kib', 'pss_kib', 'anonymous_kib')}
repeat_comparison = {'samples': repeat_points, 'expected_cluster_delta_kib': expected,
                     'observed_delta_kib': repeat_deltas,
                     'residual_delta_kib': {key: value - expected for key, value in repeat_deltas.items()},
                     'method': repeat['method'],
                     'endpoint_limitation': 'Last external sample has 99940 written video frames; all rounded track capacities equal those at final 100000, so expected cluster-byte delta is unchanged.'}

document = {
    'schema': 'asciiflow-d1b-MOV-memory-attribution-v1', 'date': '2026-10-09',
    'container': {'selected_muxer': 'mp4 (MOV muxer implementation)', 'fragmented': False,
                  'movflags': '0 default; application passes no header dictionary, no private movflags setter',
                  'hybrid_fragmented': False, 'cluster_written_bytes': 0,
                  'boxes': boxes, 'format_probe_command': probe_command, 'format_probe': probe},
    'FFmpeg': identity,
    'implementation': {'MOVIentry_bytes': 72, 'capacity_quantum_entries': 1024,
                       'formula': 'sum_over_tracks(ceil(entries / 1024) * 1024 * 72)',
                       'lifetime': 'cluster retained during non-fragmented packet writing; used by stco/co64, stsz, stsc, stts, ctts/stss as applicable when av_write_trailer writes moov. av_write_trailer then calls deinit_muxer -> mov_free (mux.c:1267); failed-job context destruction also deinitializes the initialized muxer.',
                       'trailer_temporaries': 'stts/ctts temporary arrays are allocated and freed while writing final tables, not retained per-packet structures throughout the pre-trailer sampling interval.',
                       'secondary_cluster': 'cluster_written allocated only under FF_MOV_FLAG_HYBRID_FRAGMENTED; not used in this production path.',
                       'sample_entry_scope': 'HEVC/H264/AAC one MOVIentry per muxed packet; AAC PCM sample duration is not an entry-count multiplier.'},
    'paths': records, 'default_C_repeat': repeat_comparison,
    'diagnostic': {'new_media_runs': 0, 'audio_off_matched_experiment': 'Not run: existing exact-package model and real traces already establish a significant unexplained residual; no extra soak needed to decide the stated hypothesis.',
                   'fragmented_MP4_experiment': 'Not run; production format unchanged.'},
    'classification': 'UnexplainedResidualGrowth (classification B); required MOV index component is ExpectedContainerIndexGrowth, but does not explain all observed growth.',
    'not_claimed': ['Residual proves a resource leak', 'cluster_written duplicates ordinary MP4 index',
                    'Exact allocation/RSS attribution', 'Constant-memory or duration-independent muxing',
                    'Persistent-process boundedness', 'New production support'],
    'memory_contract': 'No unexplained frame-count-correlated memory growth beyond container/runtime structures whose required growth has been explicitly accounted for.',
    'D1B': 'NOT SEALED', 'D1': 'NOT SEALED', 'D2_justified': False, 'production_changes': False,
}
(out / 'result.json').write_text(json.dumps(document, indent=2) + '\n')
print(json.dumps({'classification': document['classification'], 'measurement_C': records[2]['measurement_comparison'],
                  'default_C_repeat': repeat_comparison}, indent=2))
