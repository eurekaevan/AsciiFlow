"""Retain the small source-specific supplement without replacing old evidence."""
import hashlib
import json
from pathlib import Path
import tarfile

root = Path('/home/eureka/Documents/AsciiFlow')
base = root / 'target/stage54d1b-mov-attribution'
evidence = root / 'tests/soak/evidence'
result = json.loads((base / 'result.json').read_text())
sha = lambda p: hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
destination = evidence / 'd1b-mov-attribution-evidence.tar.gz'
manifest_path = evidence / 'd1b-mov-attribution-manifest.json'
assert not destination.exists() and not manifest_path.exists()
files = [(base / 'result.json', 'result.json'),
         (root / 'target/d1b-mov-attribution.py', 'reproduction/d1b-mov-attribution.py'),
         (root / 'target/d1b-retain-mov-attribution.py', 'reproduction/d1b-retain-mov-attribution.py'),
         (root / 'target/stage54d1b-long-soak/mov-index-model/sizeof.c', 'reproduction/sizeof.c')]
source = base / 'source'
for name in ('provenance.json', 'ffmpeg.spec', 'ffmpeg-chromium.patch',
             'ffmpeg-allow-fdk-aac-free.patch', '25e187f8494966377a4b9d077260ce7b501a911c.patch'):
    files.append((source / name, 'source/' + name))
for name in ('libavformat/movenc.c', 'libavformat/movenc.h', 'libavformat/mux.c',
             'libavformat/avformat.c', 'COPYING.GPLv3', 'COPYING.LGPLv2.1'):
    files.append((source / 'ffmpeg-8.1.3' / name, 'source/ffmpeg-8.1.3/' + name))
members = []
with tarfile.open(destination, 'x:gz') as archive:
    for path, name in files:
        archive.add(path, arcname=name, recursive=False)
        members.append({'path': name, 'bytes': path.stat().st_size, 'sha256': sha(path)})
manifest = {'schema': 'asciiflow-d1b-MOV-attribution-evidence-v1',
            'archive': str(destination.relative_to(root)), 'archive_sha256': sha(destination),
            'archive_bytes': destination.stat().st_size, 'members': members,
            'original_soak_evidence': 'tests/soak/evidence/d1b-long-soak-manifest.json',
            'exclusions': 'No media, executables, full SRPM or full native tree retained; exact signed source RPM URL/hash and relevant package source/patches retained.',
            'reproduce': 'Extract matching signed SRPM from recorded URL, apply declared spec patches, compile recorded sizeof command, restore old non-media evidence to its recorded root, then run the retained attribution script. Large output is needed only for the small -show_format probe, not for packet-count/model arithmetic.'}
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
supplement = evidence / 'd1b-mov-attribution.json'
supplement.write_text(json.dumps(result, indent=2) + '\n')
receipt_path = root / 'tests/soak/stage54d1b-long-soak.json'
receipt = json.loads(receipt_path.read_text())
receipt['memory_gate'] = result['memory_contract']
receipt['memory_decision'] = 'NOT SEALED: exact-package rounded MOV index accounts for 10152 KiB of the C late-interval increase, leaving 8304 KiB in default production (8328 KiB measurement). Required index growth is not a leak; unexplained residual remains unqualified, not a proven leak.'
receipt['remaining_gates'] = ['Path C single-job memory qualification: significant frame-count-correlated residual remains after exact-package rounded per-track MOV cluster model.']
receipt['memory_attribution'] = {
    'receipt': str(supplement.relative_to(root)), 'sha256': sha(supplement),
    'manifest': str(manifest_path.relative_to(root)), 'archive': manifest['archive'],
    'archive_sha256': manifest['archive_sha256'], 'classification': result['classification'],
    'default_C_repeat': result['default_C_repeat'],
    'previous_rough_model': 'Preserved in prior archive; current exact-package capacity-rounded review supersedes the unrounded approximation, not the measured observations.'}
receipt['limitations'][0] = 'Exact-package per-track rounded MOV cluster capacity is required allocation state, not exact RSS attribution. Default C still has 8304 KiB residual over 50k to last (99940) sample; final100k capacities are the same.'
assert receipt['status'] == receipt['d1_overall'] == 'NOT SEALED'
assert receipt['d1a'] == 'SEALED' and not receipt['d2_started']
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'archive_bytes': manifest['archive_bytes'], 'archive_sha256': manifest['archive_sha256'],
                  'members': len(members), 'supplement_sha256': sha(supplement)}, indent=2))
